package ex1;

/**
 * Created by: Ken
 * Created on: 23/02/2023
 * Student no: X00190944
 * Group/Year: 2A
 */

public class TestEmployee {
    public static void main(String[] args) {
        Employee emp1 = new Employee("John Smith", 90024, 40, 30.0);
        emp1.print();
    }// Main
}// Class - Main
