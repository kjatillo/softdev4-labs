package ex1;

/**
 * Created by: Ken
 * Created on: 23/02/2023
 * Student no: X00190944
 * Group/Year: 2A
 */

public class TestTrainee {
    public static void main(String[] args) {
        Trainee t1 = new Trainee("Mary Jones", 97778, 20, 15, 10);
        t1.print();
    }// Main
}// Class - TestTrainee
